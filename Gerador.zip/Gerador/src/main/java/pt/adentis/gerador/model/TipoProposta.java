package pt.adentis.gerador.model;

import java.time.LocalDate;

public class TipoProposta {
	
	private int id;
	private String p_tipo;

	public int getId() {
		return id;
	}
	
	public String getP_tipo() {
		return p_tipo;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public void setP_tipo(String p_tipo) {
		this.p_tipo = p_tipo;
	}
	
}
