package pt.adentis.gerador.dao;

import java.util.List;

import pt.adentis.gerador.model.TipoContrato;

public interface TipoContratoDAO {
	
	List <TipoContrato> listaTipoContrato();

}
