package pt.adentis.gerador.action;

import java.util.ArrayList;
import java.util.List;

public class TemplateBuilder {
	
	private List <String> fieldList;
	
	
	public TemplateBuilder() {
		fieldList = new ArrayList<String>();
		
		
	}
	
	public void buildFile(List <String> fieldList) {
		
		
	}

}
