package pt.adentis.gerador.dao;

import java.util.List;

import org.hibernate.SessionFactory;

import pt.adentis.gerador.model.Geral;

public class GeralDAOImpl implements GeralDAO {
	
	private SessionFactory sessionFactory;

	@Override
	public List<Geral> listaPropostas() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean insereProposta() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean getProposta() {
		// TODO Auto-generated method stub
		return false;
	}
	
	

}
