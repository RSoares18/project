package pt.adentis.gerador.model;

public class CatProfissional {
	
	private int id;
	private String n_cat_prof;
	
	public int getId() {
		return id;
	}
	
	public String getN_cat_prof() {
		return n_cat_prof;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public void setN_cat_prof(String n_cat_prof) {
		this.n_cat_prof = n_cat_prof;
	}

}
