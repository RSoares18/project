package pt.adentis.gerador.dao;

import java.util.List;

import pt.adentis.gerador.model.CatProfissional;

public interface CatProfissionalDAO {
	
	List <CatProfissional> listaCatProfissional();

}
