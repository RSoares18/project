package pt.adentis.gerador.dao;

import java.util.List;

import pt.adentis.gerador.model.TipoProposta;

public interface TipoPropostaDAO {
	
	List<TipoProposta>listaTipoProposta();

}
