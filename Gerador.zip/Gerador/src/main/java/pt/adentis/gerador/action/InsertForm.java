package pt.adentis.gerador.action;

public class InsertForm {

}
